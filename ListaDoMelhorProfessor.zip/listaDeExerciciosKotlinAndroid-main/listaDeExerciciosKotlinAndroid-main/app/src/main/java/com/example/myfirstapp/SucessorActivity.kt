package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class SucessorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sucessor)
    }

    fun Sucessor(view: View) {
        //ENTRADA
        val editTextNumero = findViewById<EditText>(R.id.etNumero)
        val num = editTextNumero.text.toString().toDouble()

        //PROCESSAMENTO
        var suc = num + 1
        var ant = num - 1

        //SAÍDA

        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "O Sucessor é $suc e o Antecessor é $ant"

        }

    }
}