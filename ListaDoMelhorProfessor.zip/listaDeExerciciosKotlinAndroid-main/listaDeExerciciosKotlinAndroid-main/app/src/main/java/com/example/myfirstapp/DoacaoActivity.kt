package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class DoacaoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doacao)
    }

    fun Doacao(view: View) {
        //Entrada
        val editTextIdade = findViewById<EditText>(R.id.etIdade)
        val idade = editTextIdade.text.toString().toDouble()

        //Processamento
        val situacao =  if(idade >= 18 && idade <= 67) "Você pode doar sangue!"
        else "Você não pode doar sangue!"

        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = situacao
        }
    }
}

