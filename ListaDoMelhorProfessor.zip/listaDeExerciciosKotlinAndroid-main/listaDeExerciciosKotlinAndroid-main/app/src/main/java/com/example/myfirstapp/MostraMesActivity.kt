package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MostraMesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostra_mes)
    }

    fun Mes(view: View) {

        val editTextMes = findViewById<EditText>(R.id.etMes)
        val nmes = editTextMes.text.toString().toInt()


        val numeroMes = when(nmes) {
            1 -> "Janeiro possui 31 dias"
            2 -> "Fevereiro possui 28 dias"
            3 -> "Março possui 31 dias"
            4 -> "Abril possui 30 dias"
            5 -> "Maio possui 31 dias"
            6 -> "Junho possui 30 dias"
            7 -> "Julho possui 31 dias"
            8 -> "Agosto possui 31 dias"
            9 -> "Setembro possui 30 dias"
            10 -> "Outubro possui 31 dias"
            11 -> "Novembro possui 30 dias"
            12 -> "Dezembro possui 31 dias"
            else -> "Entrada Inválida"
        }
        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = numeroMes
        }
    }
}
